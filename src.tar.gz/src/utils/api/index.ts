export * from "./major";
export * from "./user";
export * from "./clazz";
export * from "./admin";